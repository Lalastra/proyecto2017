/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.Date;
/**
 *
 * @author 1gprog10
 */
public class Administracion extends Trabajador{
    
    public Administracion(int idtrab, String dni, String jefe, String nombre, String apellidouno, String apellidodos, String calle, String portal, String piso, String mano, String telefempre,
                      String telefperso, int salario, Date fecha_nac, String categoria, String centro)
    {
        super(idtrab, dni, jefe, nombre, apellidouno, apellidodos, calle, portal, piso, mano, telefempre, telefperso, salario, fecha_nac, categoria, centro);
    }
    public Administracion() {
        super();
    }
    
}
