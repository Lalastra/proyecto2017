/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import Controladora.Main;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author 1gprog10
 */
public class TrabajadorBD {
    
    private static ArrayList<Trabajador> trabajadoreslist;
    
    public static Trabajador getTrabajadores(String pDni){
        
        try {
            CallableStatement cs = GenericaBD.getCon().prepareCall("{call LECTURA_CEN_TRAB.ID_TRABAJADOR(?,?)}");
            
            cs.setString(1, pDni);
            
            cs.registerOutParameter(2, OracleTypes.CURSOR);
            cs.execute();
            
            ResultSet rs = (ResultSet) cs.getObject(2);
            if(!rs.next()){
                return null;
            }else{
                try {
                    if(rs.getString("CATEGORIA").equalsIgnoreCase("logistica")){
                        Trabajador t = new Logistica(rs.getInt("IDTRAB"),rs.getString("DNI"), rs.getString("JEFE"), rs.getString("NOMBRE"), rs.getString("APELLIDOUNO"),
                                rs.getString("APELLIDODOS"), rs.getString("CALLE"), rs.getString("PORTAL"), rs.getString("PISO"), rs.getString("MANO"),
                                rs.getString("TELEFEMPRE"), rs.getString("TELEFPERSO"), rs.getInt("SALARIO"), rs.getDate("FECHA_NAC"),rs.getString("CATEGORIA"),
                                rs.getString("CENTRO"));
                        return t;
                    }else{
                        Trabajador t = new Administracion(rs.getInt("IDTRAB"),rs.getString("DNI"), rs.getString("JEFE"), rs.getString("NOMBRE"), rs.getString("APELLIDOUNO"),
                                rs.getString("APELLIDODOS"), rs.getString("CALLE"), rs.getString("PORTAL"), rs.getString("PISO"), rs.getString("MANO"),
                                rs.getString("TELEFEMPRE"), rs.getString("TELEFPERSO"), rs.getInt("SALARIO"), rs.getDate("FECHA_NAC"),rs.getString("CATEGORIA"),
                                rs.getString("CENTRO"));
                        return t;
                    }
                } catch (Exception e) {
                    System.out.println("Error en el creadp del trabajador");
                    return null;
                }
            } 
        }catch (Exception ex) {
            System.out.println("Error al obtener el trabajador");
            JOptionPane.showMessageDialog(null,ex.getMessage());
            return null;
        }
    }
    
    public static ArrayList<Trabajador> getTrabajadoresCentros(String pId){
        try {
            CallableStatement cs = GenericaBD.getCon().prepareCall("{call LECTURA_CEN_TRAB.V_TRABAJADOR(?,?)}");
            cs.setString(1, pId);
            cs.registerOutParameter(2, OracleTypes.CURSOR);
            cs.execute();
            ResultSet rs = (ResultSet) cs.getObject(2);
            trabajadoreslist = new ArrayList();
            if(!rs.next()){
                return null;
            }
            do{
                try {
                     if(rs.getString("CATEGORIA").equalsIgnoreCase("logistica")){
                        Trabajador t = new Logistica(rs.getInt("IDTRAB"),rs.getString("DNI"), rs.getString("JEFE"), rs.getString("NOMBRE"), rs.getString("APELLIDOUNO"),
                                rs.getString("APELLIDODOS"), rs.getString("CALLE"), rs.getString("PORTAL"), rs.getString("PISO"), rs.getString("MANO"),
                                rs.getString("TELEFEMPRE"), rs.getString("TELEFPERSO"), rs.getInt("SALARIO"), rs.getDate("FECHA_NAC"),rs.getString("CATEGORIA"),
                                rs.getString("CENTRO"));
                        trabajadoreslist.add(t);
                    }else{
                        Trabajador t = new Administracion(rs.getInt("IDTRAB"),rs.getString("DNI"), rs.getString("JEFE"), rs.getString("NOMBRE"), rs.getString("APELLIDOUNO"),
                                rs.getString("APELLIDODOS"), rs.getString("CALLE"), rs.getString("PORTAL"), rs.getString("PISO"), rs.getString("MANO"),
                                rs.getString("TELEFEMPRE"), rs.getString("TELEFPERSO"), rs.getInt("SALARIO"), rs.getDate("FECHA_NAC"),rs.getString("CATEGORIA"),
                                rs.getString("CENTRO"));
                        trabajadoreslist.add(t);
                    }
                } catch (Exception e) {
                    System.out.println("Error al crear el nuevo trabajador");
                    return null;
                }
            }while(rs.next());
            return trabajadoreslist;
        }catch (Exception ex) {
            System.out.println("Error al acceder a los datos del trabajador");
            return null;
        }
    }

    public static void insertar(Trabajador t) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("INSERT INTO TRABAJADORES VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setInt(1, t.getIdtrab());
            ps.setString(2, t.getDni());
            ps.setString(3, t.getJefe());
            ps.setString(4, t.getNombre());
            ps.setString(5, t.getApellidouno());
            ps.setString(6, t.getApellidodos());
            ps.setString(7, t.getCalle());
            ps.setString(8, t.getPortal());
            ps.setString(9, t.getPiso());
            ps.setString(10, t.getMano());
            ps.setString(11, t.getTelefempre());
            ps.setString(12, t.getTelefperso());
            ps.setInt(13, t.getSalario());
            java.sql.Date fecha = new java.sql.Date(t.getFecha_nac().getTime());
            ps.setDate(14, fecha);
            ps.setString(15, t.getCategoria());
            ps.setString(16, t.getCentro());
            if(t.getClass() == Main.getClaseLogistica()){
                ps.setString(15, "logistica");
            }else{
                ps.setString(15, "administracion");
            }
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error con la inserción");
        }
    }

    public static void modificar(Trabajador t) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("UPDATE TRABAJADORES SET IDTRAB = ?, DNI = ?,JEFE = ?, NOMBRE = ?, APELLIDOUNO = ?, APELLIDODOS= ?, CALLE = ?, PORTAL = ?, PISO = ?, MANO = ?, TELEFEMPRE = ?, TELEFPERSO = ?, SALARIO = ?, FECHA_NAC = ?,CATEGORIA = ?,CENTRO = ?, WHERE DNI = ? ");
            ps.setInt(1, t.getIdtrab());
            ps.setString(2, t.getDni());
            ps.setString(3, t.getJefe());
            ps.setString(4, t.getNombre());
            ps.setString(5, t.getApellidouno());
            ps.setString(6, t.getApellidodos());
            ps.setString(7, t.getCalle());
            ps.setString(8, t.getPortal());
            ps.setString(9, t.getPiso());
            ps.setString(10, t.getMano());
            ps.setString(11, t.getTelefempre());
            ps.setString(12, t.getTelefperso());
            ps.setInt(13, t.getSalario());
            java.sql.Date fecha = new java.sql.Date(t.getFecha_nac().getTime());
            ps.setDate(14, fecha);
            ps.setString(15, t.getCategoria());
            ps.setString(16, t.getCentro());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error con el modificado");
        }
    }

    public static void borrar(Trabajador t) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("DELETE FROM TRABAJADORES WHERE DNI = ?");
            ps.setString(1, t.getDni());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error con el borrado");
        }
    }
}
