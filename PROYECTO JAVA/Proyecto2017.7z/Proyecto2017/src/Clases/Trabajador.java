/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
import java.util.Date;
/**
 *
 * @author 1gprog10
 */
public class Trabajador {
    
   private int idtrab;
   private String dni;
   private String jefe;
   private String nombre;
   private String apellidouno;
   private String apellidodos;
   private String calle;
   private String portal;
   private String piso;
   private String mano;
   private String telefempre;
   private String telefperso;
   private int salario;
   private Date fecha_nac;
   private String categoria;
   private String centro;

    public Trabajador(){
    }
    
    public Trabajador(int idtrab, String dni, String jefe, String nombre, String apellidouno, String apellidodos, String calle, String portal, String piso, String mano, String telefempre,
                      String telefperso, int salario, Date fecha_nac, String categoria, String centro)
    {
        this.idtrab = idtrab;
        this.dni = dni;
        this.jefe = jefe;
        this.nombre = nombre;
        this.apellidouno = apellidouno;
        this.apellidodos = apellidodos;
        this.calle = calle;
        this.portal = portal;
        this.piso = piso;
        this.mano = mano;
        this.telefempre = telefempre;
        this.telefperso = telefperso;
        this.salario = salario;
        this.fecha_nac = fecha_nac;
        this.categoria = categoria;
        this.centro = centro;
        
    }
    public int getIdtrab() {
        return idtrab;
    }

    public void setIdtrab(int idtrab) {
        this.idtrab = idtrab;
    }
    
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getJefe() {
        return jefe;
    }

    public void setJefe(String jefe) {
        this.jefe = jefe;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidouno() {
        return apellidouno;
    }

    public void setApellidouno(String apellidouno) {
        this.apellidouno = apellidouno;
    }

    public String getApellidodos() {
        return apellidodos;
    }

    public void setApellidodos(String apellidodos) {
        this.apellidodos = apellidodos;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getPortal() {
        return portal;
    }

    public void setPortal(String portal) {
        this.portal = portal;
    }

    public String getPiso() {
        return piso;
    }

    public void setPiso(String piso) {
        this.piso = piso;
    }

    public String getMano() {
        return mano;
    }

    public void setMano(String mano) {
        this.mano = mano;
    }

    public String getTelefempre() {
        return telefempre;
    }

    public void setTelefempre(String telefempre) {
        this.telefempre = telefempre;
    }

    public String getTelefperso() {
        return telefperso;
    }

    public void setTelefperso(String telefperso) {
        this.telefperso = telefperso;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    public Date getFecha_nac() {
        return fecha_nac;
    }

    public void setFecha_nac(Date fecha_nac) {
        this.fecha_nac = fecha_nac;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getCentro() {
        return centro;
    }

    public void setCentro(String centro) {
        this.centro = centro;
    }

}
