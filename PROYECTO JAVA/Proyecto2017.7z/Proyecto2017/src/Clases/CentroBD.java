/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import Controladora.Main;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;
/**
 *
 * @author 1gprog10
 */
public class CentroBD {
    
    public static void buscarCentro(Integer pId) {
        try {
            Connection con = GenericaBD.getCon();
            CallableStatement cs = GenericaBD.getCon().prepareCall("{call LECTURA_CEN_TRAB.V_CENTRO(?,?)}");
            cs.setInt(1, pId);
        } catch (SQLException ex) {
            System.out.println("Error al buscar el centro" + ex.getMessage());
        }
    }

    public static boolean insertar(Centro c) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("INSERT INTO CENTROS (IDCENTRO, NOMBRE,  CALLE, NUMERO, CP, CIUDAD, PROVINCIA, TELEFONO) VALUES (?,?,?,?,?,?,?,?)");
            ps.setInt(1, c.getIdcentro());
            ps.setString(2, c.getNombre());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getCalle());
            ps.setString(5, String.valueOf(c.getNumero()));
            ps.setString(6, String.valueOf(c.getCp()));
            ps.setString(7, c.getCiudad());
            ps.setString(8, c.getProvincia());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Error con la insercion" + e.getMessage());
            return false;
        }
    }


    public static boolean modificar(Centro c) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("UPDATE CENTROS SET IDCENTRO = ?,NOMBRE = ?, TELEFONO = ?, CALLE = ?, NUMERO = ?, CODPOSTAL = ?, CIUDAD = ?, PROVINCIA = ? WHERE IDCENTRO = ?");
            ps.setInt(1, c.getIdcentro());
            ps.setString(2, c.getNombre());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getCalle());
            ps.setString(5, String.valueOf(c.getNumero()));
            ps.setString(6, String.valueOf(c.getCp()));
            ps.setString(7, c.getCiudad());
            ps.setString(8, c.getProvincia());
            
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Error con el modificado" + ex.getMessage());
            return false;
        }
    }

    public static boolean borrar(Centro c) {
        try {
            PreparedStatement ps = GenericaBD.getCon().prepareStatement("DELETE FROM CENTROS WHERE IDCENTRO = ?");
            ps.setInt(1, c.getIdcentro());
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Error con el borrado");
            return false;
        }
    }
}
