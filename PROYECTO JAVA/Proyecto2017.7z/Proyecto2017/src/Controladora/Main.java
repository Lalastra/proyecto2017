/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladora;

import Clases.GenericaBD;
import Clases.Logistica;
import Vista.*;
/**
 *
 * @author 1gprog10
 */
public class Main {

private static Sesion vs;

    public static void main(String[] args) {
        
        GenericaBD.abrirConexion();
        vs = new Sesion();
        vs.setLocationRelativeTo(null);
        vs.setVisible(true);
        
    }
    public static Class getClaseLogistica(){
        return Logistica.class.getClass();
    }
    
}
